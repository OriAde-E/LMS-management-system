from  ...account_creation_was_successfull import createContent

def sendOTPStatus(otp):
    return createContent(otp)
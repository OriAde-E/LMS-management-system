import React from "react";
import AddBookForm from "./AddNewBooks";

export default function Page() {
  return <AddBookForm />;
}

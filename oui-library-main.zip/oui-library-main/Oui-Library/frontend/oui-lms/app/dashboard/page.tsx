import { title } from "@/components/primitives";

export default function AboutPage() {
  return <div className="w-full h-full"></div>;
}

# LibrarySystem
The Odudwa University Library Management System is a comprehensive solution designed to streamline library operations and enhance the overall library experience at Odudwa University. This system is built with Next.js for the frontend and Django for the backend, along with Django Rest Framework for building RESTful APIs
